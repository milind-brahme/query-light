JFontChooser

 JFontChooser is a swing-based java component for font selection.
